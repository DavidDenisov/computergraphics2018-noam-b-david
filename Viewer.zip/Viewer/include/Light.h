#pragma once

/*
 * Light class. Holds light source information and data.
 */
class Light
{
public:
	Light();
	~Light();
};
