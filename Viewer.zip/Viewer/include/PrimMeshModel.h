#pragma once
#include "MeshModel.h"


class PrimMeshModel : public MeshModel 
{
public:
	PrimMeshModel(); //primitive MeshModel - task2
};